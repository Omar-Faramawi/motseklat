<div class="col-sm-8">
    <div class="top-ads banner">
        <?php $this->load->view('general_ads/728x90_blue'); ?>
    </div>
</div>