<div>
    <!-- call general ads 250x400 -->
    <?php $this->load->view('general_ads/250x400'); ?>
</div>