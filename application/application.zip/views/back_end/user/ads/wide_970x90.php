<div class="col-sm-12">
    <div class="center">
        <?php $this->load->view('general_ads/728x90_default'); ?>
    </div>
</div>