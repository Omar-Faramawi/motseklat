<div class="cell-8 margin-top-5 padd-horizontal-20">
    <!-- call general ads 728x90 -->
    <?php $this->load->view('general_ads/728x90_blue'); ?>
</div>