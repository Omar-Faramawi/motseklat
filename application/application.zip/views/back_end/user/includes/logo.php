<div class="logo left cell-3">
    <a href="<?=base_url('home/')?>"></a>
</div>