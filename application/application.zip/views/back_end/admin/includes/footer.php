<div class="footer clearfix">
    <div class="footer-inner">
        جميع الحقوق محفوظة © 2015
    </div>
    <div class="footer-items">
        <span class="go-top"><i class="clip-chevron-up"></i></span>
    </div>
</div>