<li class="widget blog-cat-w fx animated fadeInRight" data-animate="fadeInRight">
    <h3 class="widget-head">
        <span class="chain-t-left"></span>
        .:إعلان:.</h3>
    <div class="widget-content">
        <img src="<?= base_url('assets/front_end/images/ads/square-ads.png') ?>" />
    </div>
    <span class="chain-b-right"></span>
    <span class="chain-b-left"></span>
</li>