<div class="col-sm-12">
    <h4 class="block-head">إعــــــــــــــــــــــــــــلان</h4>		
    <div class="center">
        <div class="padd-bottom-10 fx animated fadeInLeft" data-animate="fadeInLeft">
            <img src="<?= base_url('assets/front_end/images/ads/wide-ads.png') ?>" />
        </div>
    </div>
</div>