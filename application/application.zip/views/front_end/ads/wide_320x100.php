<div class="cell-12">
    <div class=" center">
        <div style="" class="fx animated fadeInLeft" data-animate="fadeInLeft">
            <?php $this->load->view('general_ads/320x100'); ?>
        </div>
    </div>
</div>