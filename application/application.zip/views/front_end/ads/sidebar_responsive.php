<li class="widget blog-cat-w fx animated fadeInRight" data-animate="fadeInRight">
    <h3 class="widget-head">
        <span class="chain-t-left"></span>
        </h3>
    <div class="widget-content">
        <?php $this->load->view('general_ads/responsive'); ?>
    </div>
    <span class="chain-b-right"></span>
    <span class="chain-b-left"></span>
</li>