<li class="widget blog-cat-w fx animated fadeInRight" data-animate="fadeInRight">
    <h3 class="widget-head">
        <span class="chain-t-left"></span>
        </h3>
    <div class="widget-content" style="height:270px;">
        <?php $this->load->view('general_ads/250x250'); ?>
    </div>
    <span class="chain-b-right"></span>
    <span class="chain-b-left"></span>
</li>