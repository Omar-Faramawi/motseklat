<li class="widget search-w fx animated fadeInRight" data-animate="fadeInRight">
    <h3 class="widget-head">
        <span class="chain-t-left"></span>
        .: شاركنا على الفيس بوك :.</h3>
    <div class="widget-content">
        <div id="fb-root"></div>
        <script>(function (d, s, id) {
                var js, fjs = d.getElementsByTagName(s)[0];
                if (d.getElementById(id))
                    return;
                js = d.createElement(s);
                js.id = id;
                js.src = "//connect.facebook.net/en_GB/sdk.js#xfbml=1&appId=1425549234374699&version=v2.0";
                fjs.parentNode.insertBefore(js, fjs);
            }(document, 'script', 'facebook-jssdk'));</script>
        <div class="fb-like-box" data-href="https://www.facebook.com/motseklat" data-width="240" data-colorscheme="light" data-show-faces="true" data-header="false" data-stream="false" data-show-border="false"></div>
    </div>
    <span class="chain-b-right"></span>
    <span class="chain-b-left"></span>
</li>