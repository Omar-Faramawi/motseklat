<div class="sectionWrapper padd-top-15" style="padding-bottom: 30px;">
    <div class="container">
        <h3 class="block-head">إحــصــائيـــــــــــات</h3>
    </div>
    <div class="fun-staff staff-1 block-bg-1 sectionWrapper">
        <div class="container">
            <!-- staff item start -->
            <div class="cell-2 fx" data-animate="fadeInDown" data-animation-delay="200">
                <!--<div class="fun-number">1962</div>-->
                <a target="_blank" href="<?= base_url('home/members/1/أفراد') ?>">
                    <div class="fun-text main-bg">أفــراد</div>
                    <div class="fun-icon"><i class="fa fa-user"></i></div>
                </a>
            </div>
            <!-- staff item end -->
            <!-- staff item start -->
            <div class="cell-2 fx" data-animate="fadeInDown" data-animation-delay="400">
                <!--<div class="fun-number">136</div>-->
                <a target="_blank" href="<?= base_url('home/members/2/تجار مستقلون') ?>">
                    <div class="fun-text main-bg">تجار مستقلون</div>
                    <div class="fun-icon"><i class="fa fa-group"></i></div>
                </a>
            </div>
            <!-- staff item end -->

            <!-- staff item start -->
            <div class="cell-4 fx" data-animate="fadeInDown">
                <div class="fun-title extraBold"><div class="foot-logo"></div></div>
            </div>
            <div class="cell-2 fx" data-animate="fadeInDown" data-animation-delay="600">
                <!--<div class="fun-number">2350</div>-->
                <a target="_blank" href="<?= base_url('home/members/3/معارض') ?>">
                    <div class="fun-text main-bg">معـــارض</div>
                    <div class="fun-icon"><i class="fa fa-cog"></i></div>
                </a>
            </div>
            <!-- staff item end -->

            <!-- staff item start -->
            <div class="cell-2 fx" data-animate="fadeInDown" data-animation-delay="800">
                <!--<div class="fun-number">985</div>-->
                <a target="_blank" href="<?= base_url('home/members/4/وكلاء') ?>">
                    <div class="fun-text main-bg">وكـــلاء</div>
                    <div class="fun-icon"><i class="fa fa-globe"></i></div>
                </a>
            </div>
            <!-- staff item end -->

        </div><!-- .container end -->
    </div>
</div>