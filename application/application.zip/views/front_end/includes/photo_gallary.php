<h4 class="block-head">                                    
    مكتبة الصور
    <a href="#">مشاهدة المزيد<span class="fa fa-plus"></span></a>
</h4>
<div class="news-masnory">
    <ul class="gallery">
        <li>
            <a class="zoom" href="<?php echo base_url(); ?>assets/front_end/images/portfolio/1.jpg" data-gal="prettyPhoto[pp_gal]"><img alt="" src="<?php echo base_url(); ?>assets/front_end/images/portfolio/1.jpg" /><span class="img-overlay"></span></a>
        </li>
        <li>
            <a class="zoom" href="<?php echo base_url(); ?>assets/front_end/images/portfolio/1.jpg" data-gal="prettyPhoto[pp_gal]"><img alt="" src="<?php echo base_url(); ?>assets/front_end/images/portfolio/1.jpg" /><span class="img-overlay"></span></a>
        </li>
        <li>
            <a class="zoom" href="<?php echo base_url(); ?>assets/front_end/images/portfolio/1.jpg" data-gal="prettyPhoto[pp_gal]"><img alt="" src="<?php echo base_url(); ?>assets/front_end/images/portfolio/1.jpg" /><span class="img-overlay"></span></a>
        </li>
        <li>
            <a class="zoom" href="<?php echo base_url(); ?>assets/front_end/images/portfolio/1.jpg" data-gal="prettyPhoto[pp_gal]"><img alt="" src="<?php echo base_url(); ?>assets/front_end/images/portfolio/1.jpg" /><span class="img-overlay"></span></a>
        </li>
        <li>
            <a class="zoom" href="<?php echo base_url(); ?>assets/front_end/images/portfolio/1.jpg" data-gal="prettyPhoto[pp_gal]"><img alt="" src="<?php echo base_url(); ?>assets/front_end/images/portfolio/1.jpg" /><span class="img-overlay"></span></a>
        </li>
        <li>
            <a class="zoom" href="<?php echo base_url(); ?>assets/front_end/images/portfolio/1.jpg" data-gal="prettyPhoto[pp_gal]"><img alt="" src="<?php echo base_url(); ?>assets/front_end/images/portfolio/1.jpg" /><span class="img-overlay"></span></a>
        </li>
        <li>
            <a class="zoom" href="<?php echo base_url(); ?>assets/front_end/images/portfolio/1.jpg" data-gal="prettyPhoto[pp_gal]"><img alt="" src="<?php echo base_url(); ?>assets/front_end/images/portfolio/1.jpg" /><span class="img-overlay"></span></a>
        </li>
        <li>
            <a class="zoom" href="<?php echo base_url(); ?>assets/front_end/images/portfolio/1.jpg" data-gal="prettyPhoto[pp_gal]"><img alt="" src="<?php echo base_url(); ?>assets/front_end/images/portfolio/1.jpg" /><span class="img-overlay"></span></a>
        </li>
        <li>
            <a class="zoom" href="<?php echo base_url(); ?>assets/front_end/images/portfolio/1.jpg" data-gal="prettyPhoto[pp_gal]"><img alt="" src="<?php echo base_url(); ?>assets/front_end/images/portfolio/1.jpg" /><span class="img-overlay"></span></a>
        </li>
        <li>
            <a class="zoom" href="<?php echo base_url(); ?>assets/front_end/images/portfolio/1.jpg" data-gal="prettyPhoto[pp_gal]"><img alt="" src="<?php echo base_url(); ?>assets/front_end/images/portfolio/1.jpg" /><span class="img-overlay"></span></a>
        </li>
        <li>
            <a class="zoom" href="<?php echo base_url(); ?>assets/front_end/images/portfolio/1.jpg" data-gal="prettyPhoto[pp_gal]"><img alt="" src="<?php echo base_url(); ?>assets/front_end/images/portfolio/1.jpg" /><span class="img-overlay"></span></a>
        </li>
        <li>
            <a class="zoom" href="<?php echo base_url(); ?>assets/front_end/images/portfolio/1.jpg" data-gal="prettyPhoto[pp_gal]"><img alt="" src="<?php echo base_url(); ?>assets/front_end/images/portfolio/1.jpg" /><span class="img-overlay"></span></a>
        </li>
        <li>
            <a class="zoom" href="<?php echo base_url(); ?>assets/front_end/images/portfolio/1.jpg" data-gal="prettyPhoto[pp_gal]"><img alt="" src="<?php echo base_url(); ?>assets/front_end/images/portfolio/1.jpg" /><span class="img-overlay"></span></a>
        </li>
        <li>
            <a class="zoom" href="<?php echo base_url(); ?>assets/front_end/images/portfolio/1.jpg" data-gal="prettyPhoto[pp_gal]"><img alt="" src="<?php echo base_url(); ?>assets/front_end/images/portfolio/1.jpg" /><span class="img-overlay"></span></a>
        </li>
        <li>
            <a class="zoom" href="<?php echo base_url(); ?>assets/front_end/images/portfolio/1.jpg" data-gal="prettyPhoto[pp_gal]"><img alt="" src="<?php echo base_url(); ?>assets/front_end/images/portfolio/1.jpg" /><span class="img-overlay"></span></a>
        </li>
        <li>
            <a class="zoom" href="<?php echo base_url(); ?>assets/front_end/images/portfolio/1.jpg" data-gal="prettyPhoto[pp_gal]"><img alt="" src="<?php echo base_url(); ?>assets/front_end/images/portfolio/1.jpg" /><span class="img-overlay"></span></a>
        </li>
        <li>
            <a class="zoom" href="<?php echo base_url(); ?>assets/front_end/images/portfolio/1.jpg" data-gal="prettyPhoto[pp_gal]"><img alt="" src="<?php echo base_url(); ?>assets/front_end/images/portfolio/1.jpg" /><span class="img-overlay"></span></a>
        </li>
        <li>
            <a class="zoom" href="<?php echo base_url(); ?>assets/front_end/images/portfolio/1.jpg" data-gal="prettyPhoto[pp_gal]"><img alt="" src="<?php echo base_url(); ?>assets/front_end/images/portfolio/1.jpg" /><span class="img-overlay"></span></a>
        </li>
    </ul>
</div>