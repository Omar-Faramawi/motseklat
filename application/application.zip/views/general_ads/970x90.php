<!-- 970*90 -->
<ins class="adsbygoogle"
     style="display:inline-block;width:970px;height:90px"
     data-ad-client="ca-pub-1540187047600238"
     data-ad-slot="8839864907"></ins>
<script>
    (adsbygoogle = window.adsbygoogle || []).push({});
</script>