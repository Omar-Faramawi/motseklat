<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Api extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->model('users_model');
        $this->load->model('groups_model');
        $this->load->model('evenets_model');

//        $this->auth->check_accessibility('user');
    }

    /*
     * NOTE: url access to any function
     * motseklat.com/api/function_name
     * also send the request parameter as post
     */

    function login() {
        $username = $this->security->xss_clean(trim($this->post('username')));
        $password = $this->security->xss_clean(trim($this->post('password')));
        if ($username == NULL or $password == NULL) {
            echo json_encode(array('status' => false, 'message' => 'يجب ملئ جميع الحقول'));
        } else {
            $data['username'] = $username;
            $data['password'] = $this->auth->encrypt($password);
            $info = $this->users_model->do_login($data);
            if ($info) {
                if ($info->active == 0) {
                    echo json_encode(array('status' => false, 'message' => 'عذراً لم تقم بتفعيل الحساب...الرجاء مراجعه بريدك الإلكتروني'));
                }
                if ($info->blocked == 1) {
                    echo json_encode(array('status' => false, 'message' => 'عذراً حسابك مقفل يرجى التواصل مع إدارة الموقع'));
                }
                if ($info->blocked == 0 and $info->active == 1) {
                    echo json_encode(array('status' => true, 'message' => 'تم تسجيل الدخول', 'user_info' => $info)); //user info is array of object contain [id,username,picture,active,blocked,user_type]
                }
            } else {
                echo json_encode(array('status' => false, 'message' => 'الرجاء التأكد من إسم المستخدم وكلمة المرور'));
            }
        }
    }

    function update_position() {
        $start_position = $this->security->xss_clean(trim($this->post('start_position')));
        $end_position = $this->security->xss_clean(trim($this->post('end_position')));
        $user_id = $this->security->xss_clean(trim($this->post('user_id')));

        $data = array();
        $data['start_position'] = $start_position;
        $data['end_position'] = $end_position;
        $data['admin_id'] = $user_id;
        $result = $this->events_model->update_event($data);
        if ($result) {
            echo json_encode(array('status' => true, 'message' => 'تم التعديل بنجاح'));
        } else {
            echo json_encode(array('status' => false, 'message' => 'الرجاء المحاولة ثانيتاً'));
        }
    }

    function get_all_events() {
        $events = $this->events_model->get_all_events();
        echo json_encode(array('events' => $events)); // array of objects
    }

    function get_user_events() {
        $user_id = $this->security->xss_clean(trim($this->post('user_id')));
        $events = $this->events_model->get_user_events($user_id);
        echo json_encode(array('events' => $events)); // array of objects
    }

    function getUsersPositionInEvent() {
        // i think it need, when any user register new account should specify his position!
    }

}

/* End of file api.php */